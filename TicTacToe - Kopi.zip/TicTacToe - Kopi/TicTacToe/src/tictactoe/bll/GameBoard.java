/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tictactoe.bll;


import javafx.scene.control.Button;
import javafx.scene.control.Label;

import java.util.ArrayList;



/**
 * @author Stegger
 */
public class GameBoard implements IGameModel {

    /**
     * Returns 0 for player 0, 1 for player 1.
     *
     * @return int Id of the next player.
     */
    private int player = 0;
    private final int winner = 0;
    private String [][] board = {{"-1","-1","-1"},{"-1","-1","-1"},{"-1","-1","-1"}};

    public int getNextPlayer() {
        if (player == 0) {
            return 1;
        } else {
            return 0;
        }
    }

    /**
     * Attempts to let the current player play at the given coordinates. It the
     * attempt is succesfull the current player has ended his turn and it is the
     * next players turn.
     *
     * @param col column to place a marker in.
     * @param row row to place a marker in.
     * @return true if the move is accepted, otherwise false. If gameOver == true
     * this method will always return false.
     */
    public boolean play(int col, int row) {
        board[row][col] = player +"";
        player = getNextPlayer();

        return true;
    }


    public boolean isGameOver() {
        for (int i = 0; i < 8; i++) {
            String line = switch (i) {
                case 0 -> board[0][0] + board[0][1] + board[0][2];
                case 1 -> board[1][0] + board[1][1] + board[1][2];
                case 2 -> board[2][0] + board[2][1] + board[2][2];
                case 3 -> board[0][0] + board[1][0] + board[2][0];
                case 4 -> board[0][1] + board[1][1] + board[2][1];
                case 5 -> board[0][2] + board[1][2] + board[2][2];
                case 6 -> board[0][0] + board[1][1] + board[2][2];
                case 7 -> board[0][2] + board[1][1] + board[2][0];
                default -> "";
            };

            if (line.equals("000")) {
                return true;
            } else if (line.equals("111")) {
                return true;
            }
        }
        return false;
    }

    /**
     * Gets the id of the winner, -1 if its a draw.
     *
     * @return int id of winner, or -1 if draw.
     */
    public int getWinner() {
        return getNextPlayer();
    }

    /**
     * Resets the game to a new game state.
     */
    public void newGame() {
        //TODO Implement this method
    }

}